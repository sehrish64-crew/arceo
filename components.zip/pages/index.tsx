'use client';
import Dashboard from '@/components/Dashboard';

export default function HomePage() {
  return <Dashboard />;
}
