'use client';

import SupportPage from '@/components/Support';

export default function DoctorsPage() {
  return (
    <div>
      <SupportPage />
    </div>
  );
}
