import React from 'react';

const DashboardPage = () => {
  return (
    <div>
      <h1>Dashboard Page</h1>
      <p>This is a placeholder for the Dashboard page.</p>
    </div>
  );
};

export default DashboardPage;
