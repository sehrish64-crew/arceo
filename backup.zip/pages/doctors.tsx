'use client';

import DoctorsTable from '@/components/DoctorsTable';

export default function DoctorsPage() {
  return (
    <div>
      <DoctorsTable />
    </div>
  );
}
