'use client';

import Clinic from '@/components/Clinic';


export default function ClinicPage() {
  return (
    <>
      <div>
        <Clinic />
      </div>
    </>
  );
}
