'use client';

import Inventories from '@/components/Inventory';

export default function Inventory() {
  return (
    <div>
      <Inventories />
    </div>
  );
}
